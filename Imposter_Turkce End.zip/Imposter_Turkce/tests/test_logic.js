/* Mantık testleri: node tests/test_logic.js */
global.window = globalThis;
require("../words.js");
const L = require("../logic.js");
const V = window.IMPOSTER_VERI;
const assert = require("assert");
const pm = L.buildPairMap(V);
let ok = 0;
function t(name, fn) { fn(); ok++; console.log("  ✓", name); }

t("en az 600 benzersiz kelime, 26 kategori", () => {
  const set = new Set(); V.KATEGORILER.forEach(k => k.kelimeler.forEach(w => set.add(L.norm(w))));
  assert(set.size >= 600); assert.strictEqual(V.KATEGORILER.length, 26);
  const total = V.KATEGORILER.reduce((a, k) => a + k.kelimeler.length, 0);
  assert.strictEqual(set.size, total, "tekrar eden kelime var");
});
t("İslam kategorisi >=150 kelime ve istenen kelimeler var", () => {
  const k = V.KATEGORILER.find(k => k.id === "islam"); assert(k.kelimeler.length >= 150);
  ["Ramazan","Oruç","İftar","Sahur","Kur’an","Kâbe","Mekke","Medine","Seccade","Başörtüsü","Valiz","Uçak"].forEach(w => assert(k.kelimeler.includes(w), w));
});
t("Peygamber/melek isimleri yok", () => {
  const yasak = ["muhammed","ibrahim","musa","isa","yusuf","nuh","cebrail","mikail","azrail","israfil"];
  const k = V.KATEGORILER.find(k => k.id === "islam");
  k.kelimeler.forEach(w => yasak.forEach(y => assert(!L.norm(w).split(" ").includes(y), w)));
});
t("Tüm kategorilerde boş/boşluklu kelime yok", () => {
  V.KATEGORILER.forEach(k => k.kelimeler.forEach(w => assert(w === w.trim() && w.length > 1)));
});
t("Çiftler: farklı kelime ve İftar–Sahur, Kedi–Köpek vb. var", () => {
  Object.entries(pm).forEach(([k, v]) => assert.notStrictEqual(L.norm(v), k));
  assert.strictEqual(pm[L.norm("Kedi")], "Köpek"); assert.strictEqual(pm[L.norm("İftar")], "Sahur");
  assert.strictEqual(pm[L.norm("Elma")], "Armut"); assert.strictEqual(pm[L.norm("Cami")], "Seccade");
  assert.strictEqual(pm[L.norm("Ramazan")], "Bayram");
});
t("Ayarlar: sanitize sınırları ve en az iki normal oyuncu", () => {
  for (let n = 3; n <= 12; n++) {
    const s = L.sanitize({ names: Array.from({ length: n }, (_, i) => "P" + i), imposters: 99 }, V);
    assert.strictEqual(s.imposters, n - 2 < 1 ? 1 : n - 2);
    assert(n - s.imposters >= 2);
  }
  assert.strictEqual(L.sanitize({ names: ["a"] }, V).names.length, 3);
  assert.strictEqual(L.sanitize(null, V).timerOn, false, "sayaç varsayılan kapalı");
});
t("Doğrulama hataları Türkçe", () => {
  const s = L.sanitize(null, V);
  assert.strictEqual(L.validate(s, V), null);
  s.names[1] = s.names[0]; assert(/Aynı isim/.test(L.validate(s, V)));
  const s2 = L.sanitize(null, V); s2.categories = []; assert(/kategori/.test(L.validate(s2, V)));
  s2.mixed = true; assert.strictEqual(L.validate(s2, V), null);
});
const rnd = L.createRng();
t("Mod A: normaller kelimeyi görür, imposter görmez, sayılar doğru (tüm oyuncu/imposter kombinasyonları)", () => {
  for (let n = 3; n <= 12; n++) for (let im = 1; im <= L.maxImposters(n); im++) for (let rep = 0; rep < 20; rep++) {
    const s = L.sanitize({ names: Array.from({ length: n }, (_, i) => "P" + i), imposters: im, mixed: true, mode: "A" }, V);
    const r = L.newRound(s, V, pm, null, rnd);
    assert.strictEqual(r.mode, "A");
    assert.strictEqual(r.players.filter(p => p.imposter).length, im);
    r.players.forEach(p => { if (p.imposter) assert.strictEqual(p.word, null); else assert.strictEqual(p.word, r.word); });
    assert(r.players.filter(p => !p.imposter).length >= 2);
  }
});
t("Mod B: imposter benzer ama farklı kelime alır", () => {
  for (let i = 0; i < 300; i++) {
    const s = L.sanitize({ names: ["A","B","C","D"], imposters: 1, mixed: true, mode: "B" }, V);
    const r = L.newRound(s, V, pm, null, rnd);
    assert.strictEqual(r.mode, "B"); assert(r.alt && L.norm(r.alt) !== L.norm(r.word));
    r.players.forEach(p => assert.strictEqual(p.word, p.imposter ? r.alt : r.word));
  }
});
t("Mod B: çift yoksa otomatik Mod A (sentetik veri)", () => {
  const fake = { KATEGORILER: [{ id: "x", ad: "X", ikon: "x", kelimeler: ["Tek"] }], CIFTLER: [] };
  const s = { names: ["A","B","C"], imposters: 1, categories: ["x"], mixed: false, mode: "B", hints: false };
  const r = L.newRound(s, fake, L.buildPairMap(fake), null, rnd);
  assert.strictEqual(r.mode, "A"); assert(r.fellBack);
});
t("Kategori seçimi: yalnızca seçili kategoriden kelime", () => {
  const s = L.sanitize({ names: ["A","B","C"], categories: ["islam"], mixed: false }, V);
  const isl = new Set(V.KATEGORILER.find(k => k.id === "islam").kelimeler);
  for (let i = 0; i < 200; i++) { const r = L.newRound(s, V, pm, null, rnd); assert(isl.has(r.word)); assert.strictEqual(r.category, "İslam"); }
  const s2 = L.sanitize({ names: ["A","B","C"], categories: ["hayvanlar","sporlar"] }, V);
  const ok2 = new Set([].concat(...V.KATEGORILER.filter(k => ["hayvanlar","sporlar"].includes(k.id)).map(k => k.kelimeler)));
  for (let i = 0; i < 200; i++) assert(ok2.has(L.newRound(s2, V, pm, null, rnd).word));
});
t("Karışık kategoriler: İslam dahil tüm kategoriler görülür", () => {
  const s = L.sanitize({ names: ["A","B","C"], categories: [], mixed: true }, V);
  const seen = new Set(); for (let i = 0; i < 6000; i++) seen.add(L.newRound(s, V, pm, null, rnd).category);
  assert.strictEqual(seen.size, 26);
});
t("Tekrar Oyna: önceki kelime tekrar etmez, roller yeniden dağılır", () => {
  const s = L.sanitize({ names: ["A","B","C","D","E"], imposters: 2, categories: ["hayvanlar"] }, V);
  let prev = null, distinctRoles = new Set();
  for (let i = 0; i < 300; i++) {
    const r = L.newRound(s, V, pm, prev, rnd);
    if (prev) assert.notStrictEqual(L.norm(r.word), L.norm(prev));
    prev = r.word; distinctRoles.add(r.players.map(p => +p.imposter).join(""));
  }
  assert(distinctRoles.size >= 8, "roller yeterince rastgele değil");
  const one = { KATEGORILER: [{ id: "x", ad: "X", ikon: "", kelimeler: ["Tek"] }], CIFTLER: [] };
  assert.strictEqual(L.newRound({ names: ["A","B","C"], imposters: 1, categories: ["x"], mixed: false, mode: "A" }, one, {}, "Tek", rnd).word, "Tek");
});
t("İpucu: yalnızca imposter'a ve yalnızca açıkken kategori gösterilir", () => {
  const s = L.sanitize({ names: ["A","B","C"], hints: true, categories: ["islam"] }, V);
  L.newRound(s, V, pm, null, rnd).players.forEach(p => assert.strictEqual(p.hint, p.imposter ? "İslam" : null));
  s.hints = false; L.newRound(s, V, pm, null, rnd).players.forEach(p => assert.strictEqual(p.hint, null));
});
t("Oy verisi yok: tur nesnesinde oy/sayaç alanı bulunmaz", () => {
  const r = L.newRound(L.sanitize(null, V), V, pm, null, rnd);
  JSON.stringify(r); assert(!Object.keys(r).some(k => /vote|oy|score|puan/i.test(k)));
});

t("Imposter-Wahl: gleiche Wahrscheinlichkeit für alle Spieler (Chi-Quadrat-nah)", () => {
  const n = 6, k = 1, N = 60000, cnt = Array(n).fill(0); let hist = [];
  for (let i = 0; i < N; i++) { const pick = L.pickImposters(n, k, hist, rnd); pick.forEach(x => cnt[x]++); hist.push(pick); if (hist.length > 6) hist.shift(); }
  const exp = N * k / n;
  cnt.forEach(c => assert(Math.abs(c - exp) / exp < 0.04, "Verteilung ungleich: " + cnt.join(",")));
});
t("Imposter-Wahl: niemand ist mehr als 2 Runden hintereinander Imposter", () => {
  [[3,1],[4,1],[5,2],[6,3],[12,10]].forEach(([n, k]) => {
    let hist = [], streak = Array(n).fill(0);
    for (let i = 0; i < 5000; i++) {
      const pick = L.pickImposters(n, k, hist, rnd);
      assert.strictEqual(pick.length, k); assert.strictEqual(new Set(pick).size, k);
      for (let p = 0; p < n; p++) { streak[p] = pick.includes(p) ? streak[p] + 1 : 0; if (n - k >= 1 && n > k) { /* Regel greift nur, wenn genug Alternativen existieren */ } }
      hist.push(pick); if (hist.length > 6) hist.shift();
    }
  });
  // streng prüfbar, wenn genug Alternativen existieren (k <= n/2)
  [[3,1],[4,1],[6,2],[8,3]].forEach(([n, k]) => {
    let hist = [], streak = Array(n).fill(0);
    for (let i = 0; i < 5000; i++) {
      const pick = L.pickImposters(n, k, hist, rnd);
      for (let p = 0; p < n; p++) { streak[p] = pick.includes(p) ? streak[p] + 1 : 0; assert(streak[p] <= 2, `Spieler ${p} war ${streak[p]}x hintereinander (n=${n},k=${k})`); }
      hist.push(pick); if (hist.length > 6) hist.shift();
    }
  });
});
t("Imposter-Wahl: Runde 2 ist unabhängig neu zufällig (verschiedene Imposter über viele Runden)", () => {
  const s = L.sanitize({ names: ["A","B","C","D","E"], imposters: 1, categories: ["hayvanlar"] }, V);
  let hist = [], seen = new Set();
  for (let i = 0; i < 200; i++) { const r = L.newRound(s, V, pm, null, rnd, hist); hist.push(r.imposterIdx); seen.add(r.imposterIdx[0]);
    assert.deepStrictEqual(r.players.map((p, ix) => p.imposter ? ix : -1).filter(x => x >= 0), r.imposterIdx); }
  assert.strictEqual(seen.size, 5);
});

require("../aciklamalar.js");
t("Worterklärungen: jedes vorhandene Wort hat eine passende, nicht leere Erklärung", () => {
  const map = L.buildExplainMap(window.IMPOSTER_ACIKLAMALAR);
  const words = []; V.KATEGORILER.forEach(k => k.kelimeler.forEach(w => words.push(w)));
  assert.strictEqual(words.length, 1056);
  words.forEach(w => {
    const e = map[L.norm(w)];
    assert(e && e.length >= 20, "Erklärung fehlt/zu kurz: " + w);
    assert(e.length <= 160, "Erklärung zu lang: " + w);
    assert.notStrictEqual(L.norm(e), L.norm(w), "Erklärung wiederholt nur das Wort: " + w);
    assert.strictEqual(L.explain(w, "X", map), e);
  });
  assert.strictEqual(Object.keys(window.IMPOSTER_ACIKLAMALAR).length, words.length, "Erklärungen ohne zugehöriges Wort vorhanden");
});
t("Worterklärungen: Ersatztext für neue Wörter ohne Erklärung", () => {
  const map = L.buildExplainMap(window.IMPOSTER_ACIKLAMALAR);
  const f = L.explain("Neuwort", "Hayvanlar", map);
  assert(f.includes("Neuwort") && f.includes("Hayvanlar") && f.includes("açıklama"));
  assert(L.explain("Neuwort", null, map).includes("Neuwort"));
  assert(L.explain("Kedi", "Hayvanlar", null).includes("Kedi")); /* Tabelle fehlt komplett */
  assert.strictEqual(L.explain("kedi", "Hayvanlar", map), map[L.norm("Kedi")], "Groß-/Kleinschreibung egal");
});
t("Zamanlayıcı biçimi", () => { assert.strictEqual(L.formatTime(180000), "03:00"); assert.strictEqual(L.formatTime(-5), "00:00"); assert.strictEqual(L.formatTime(61000), "01:01"); });
console.log("\n" + ok + " mantık testi geçti");

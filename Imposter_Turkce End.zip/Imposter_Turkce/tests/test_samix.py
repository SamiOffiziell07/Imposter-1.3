"""SAMIX-Tests (Playwright): Ladebildschirm, Logo, Worterklärung (?), Einbindung der Dateien.
Kullanım: python3 tests/test_samix.py <proje klasörü> [ekran görüntüsü klasörü]"""
import sys, os, re, json, time, pathlib, subprocess, threading, http.server, socketserver, functools
from playwright.sync_api import sync_playwright

root = pathlib.Path(sys.argv[1]).resolve()
shots = pathlib.Path(sys.argv[2]) if len(sys.argv) > 2 else None
passed = 0
def check(name, cond, extra=""):
    global passed
    if not cond:
        print("  ✗ FAIL:", name, extra); sys.exit(1)
    passed += 1; print("  ✓", name)

# --- statischer Server (für Ladetests mit künstlich verzögerten Dateien) ---
DELAY = {}      # Dateiname -> Verzögerung in Sekunden (nicht blockierend für den Test)
RELEASED = {}   # Dateiname -> Zeitpunkt der Auslieferung
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a): pass
    def do_GET(self):
        name = self.path.split("?")[0].rsplit("/", 1)[-1]
        if DELAY.get(name): time.sleep(DELAY[name])
        RELEASED[name] = time.time()
        try: super().do_GET()
        except (BrokenPipeError, ConnectionResetError): pass
Handler = functools.partial(Q, directory=str(root))
class TS(socketserver.ThreadingMixIn, socketserver.TCPServer): daemon_threads = True; allow_reuse_address = True
srv = TS(("127.0.0.1", 0), Handler)
PORT = srv.server_address[1]
threading.Thread(target=srv.serve_forever, daemon=True).start()
HTTP = f"http://127.0.0.1:{PORT}/index.html"
FILE = (root / "index.html").as_uri()

print("Dateien und Einbindung")
html = (root / "index.html").read_text(encoding="utf-8")
refs = re.findall(r'(?:src|href)="([^"#:]+?)"', html) + re.findall(r'src="(assets/[^"]+)"', (root / "app.js").read_text(encoding="utf-8"))
refs = [r for r in refs if not r.startswith("data")]
check("Alle in index.html/app.js referenzierten Dateien existieren", all((root / r).exists() for r in refs), str([r for r in refs if not (root / r).exists()]))
man = json.loads((root / "manifest.webmanifest").read_text(encoding="utf-8"))
check("Manifest-Icons existieren", all((root / i["src"]).exists() for i in man["icons"]))
from PIL import Image
lg = Image.open(root / "assets/samix-logo.png")
check("Logo-PNG hat Transparenz und Originalproportionen", lg.mode == "RGBA" and abs(lg.width / lg.height - 1248 / 1521) < 0.001 and lg.getchannel("A").getextrema()[0] == 0)
check("Original-Logo (Vorlage) liegt im Projekt", (root / "assets/samix-logo-original.jpg").exists())
check("Keine temporären Dateien/Caches im Projekt", not any(p.name in ("__pycache__", ".DS_Store") or p.suffix in (".pyc", ".tmp") for p in root.rglob("*")))

with sync_playwright() as p:
    b = p.chromium.launch()
    def newctx(w=390, h=844, dpr=3, mobile=True):
        return b.new_context(viewport={"width": w, "height": h}, device_scale_factor=dpr, has_touch=mobile, is_mobile=mobile, locale="tr-TR")
    def shot(page, name):
        if shots: page.screenshot(path=str(shots / f"{name}.png"))

    print("Ladebildschirm")
    ctx = newctx(); page = ctx.new_page(); errs = []
    page.on("pageerror", lambda e: errs.append(str(e)))
    page.add_init_script("""(()=>{let seen=false;new MutationObserver((m,o)=>{const e=document.getElementById('splash');if(e)seen=true;else if(seen){window.__gone=Date.now()/1000;o.disconnect()}}).observe(document,{childList:true,subtree:true})})()""")
    DELAY["app.js"] = 2.5
    page.goto(HTTP, wait_until="commit")
    page.wait_for_selector("#splash .sp-logo", state="visible")
    page.wait_for_function("document.getElementById('splashLogo').complete && document.getElementById('splashLogo').naturalWidth > 0")
    page.wait_for_timeout(500)
    info = page.evaluate("""(()=>{const l=document.getElementById('splashLogo');const r=l.getBoundingClientRect();
      return {nw:l.naturalWidth,nh:l.naturalHeight,w:r.width,h:r.height,x:r.x,y:r.y,vw:innerWidth,vh:innerHeight,op:getComputedStyle(document.getElementById('splash')).opacity,
              ring:!!document.querySelector('#splash .sp-ring svg'),present:!!document.getElementById('splash'),wm:document.querySelectorAll('.wordmark').length,anim:getComputedStyle(document.querySelector('#splash .sp-ring svg')).animationName, txt:document.getElementById('splash').innerText}})()""")
    shot(page, "s01_ladebildschirm")
    check("Splash sichtbar, solange das Spiel noch lädt", info["op"] == "1" and info["present"] and info["wm"] == 0, str(info))
    check("SAMIX-Logo geladen (Originalgröße 1248×1521)", info["nw"] == 1248 and info["nh"] == 1521)
    check("Logo unverzerrt (Seitenverhältnis stimmt)", abs(info["w"] / info["h"] - 1248 / 1521) < 0.01, str(info))
    check("Logo mittig und komplett im Bild", abs((info["x"] + info["w"] / 2) - info["vw"] / 2) < 2 and info["y"] > 0 and info["y"] + info["h"] < info["vh"])
    check("Ladeanimation (Ring) und Schriftzüge vorhanden", info["ring"] and "GAMES · APPS · INNOVATION" in info["txt"] and "CREATED BY SAMI" in info["txt"])
    check("Logo scharf: gerenderte Pixelhöhe <= Originalhöhe", info["h"] * 3 <= info["nh"])
    check("Ring dreht sich (CSS-Animation aktiv)", info["anim"] == "spSpin")
    page.wait_for_selector("#splash", state="detached", timeout=5000)
    t_gone = page.evaluate("window.__gone")
    check("Splash verschwindet automatisch kurz nach Spielstart (keine künstliche Wartezeit)", t_gone - RELEASED["app.js"] < 1.0, f"{t_gone - RELEASED['app.js']:.2f}s")
    check("Hauptmenü erscheint mit SAMIX-Logo", page.locator(".wordmark").is_visible() and page.locator(".logo img.logo-w").evaluate("i=>i.naturalWidth") == 1248)
    shot(page, "s02_menu")
    DELAY.clear()
    check("Keine Seitenfehler beim Laden", errs == [], str(errs))
    # Menü nach Splash bedienbar
    page.click('[data-act="newGame"]'); check("Nach dem Splash ist alles bedienbar", page.locator(".name-in").count() == 5)
    ctx.close()

    print("Schneller Start ohne Verzögerung")
    ctx = newctx(); page = ctx.new_page()
    t0 = time.time(); page.goto(FILE); page.wait_for_selector("#splash", state="detached", timeout=4000)
    check(f"Normaler Start: Splash nach {time.time()-t0:.2f}s weg", page.locator(".wordmark").is_visible())
    ctx.close()

    print("Fehlerfälle")
    ctx = newctx(); page = ctx.new_page()
    page.route("**/words.js", lambda r: r.abort())
    page.goto(HTTP); page.wait_for_selector("#splash.failed", timeout=4000)
    check("Fehlende Datei: Fehlermeldung statt Endlos-Ladebildschirm", page.locator("#splashErrMsg").is_visible() and "words.js" in page.inner_text("#splashErrMsg"))
    check("Ladering ist im Fehlerfall ausgeblendet", not page.locator("#splash .sp-ring").is_visible())
    check("„Tekrar Dene“ vorhanden", page.locator("#splashRetry").is_visible() and page.inner_text("#splashRetry") == "Tekrar Dene")
    shot(page, "s03_fehler")
    page.unroute("**/words.js")
    page.click("#splashRetry"); page.wait_for_selector("#splash", state="detached", timeout=5000)
    check("Erneut laden funktioniert", page.locator(".wordmark").is_visible())
    ctx.close()

    ctx = newctx(); page = ctx.new_page()
    page.route("**/aciklamalar.js", lambda r: r.abort())
    page.goto(HTTP); page.wait_for_selector("#splash", state="detached", timeout=5000)
    check("Fehlende Erklärungsdatei blockiert das Spiel nicht", page.locator(".wordmark").is_visible())
    ctx.close()

    ctx = newctx(); page = ctx.new_page()
    page.route("**/assets/samix-logo.png", lambda r: r.abort())
    page.goto(HTTP); page.wait_for_selector("#splash", state="detached", timeout=5000)
    check("Fehlendes Logo blockiert das Spiel nicht", page.locator(".wordmark").is_visible())
    ctx.close()

    ctx = newctx(); page = ctx.new_page()
    DELAY["app.js"] = 10.6
    page.goto(HTTP, wait_until="commit")
    page.wait_for_selector("#splash.failed", timeout=12000)
    check("Hängt der Start >10 s: Fehlermeldung + Neuladen-Button", page.locator("#splashRetry").is_visible() and "lange" in page.inner_text("#splashErrMsg"))
    DELAY.clear(); ctx.close()

    print("Logo auf verschiedenen Bildschirmen")
    for (w, h, dpr, mob, nm) in [(320, 568, 2, True, "iPhone SE 1"), (375, 667, 2, True, "iPhone 8"), (390, 844, 3, True, "iPhone 14"), (430, 932, 3, True, "iPhone Pro Max"), (768, 1024, 2, True, "iPad"), (1280, 800, 1, False, "Desktop"), (844, 390, 3, True, "iPhone quer")]:
        DELAY["app.js"] = 2.0; ctx = newctx(w, h, dpr, mob); page = ctx.new_page()
        page.goto(HTTP, wait_until="commit"); page.wait_for_function("(()=>{const l=document.getElementById('splashLogo');return l&&l.complete&&l.naturalWidth>0})()"); page.wait_for_timeout(300)
        d = page.evaluate("(()=>{const r=document.getElementById('splashLogo').getBoundingClientRect();const s=document.querySelector('#splash .sp-foot').getBoundingClientRect();const b=document.querySelector('#splash .sp-brand').getBoundingClientRect();return {w:r.width,h:r.height,top:r.top,bot:r.bottom,vw:innerWidth,vh:innerHeight,footTop:s.top,brandBot:b.bottom,ringBot:document.querySelector('#splash .sp-ring').getBoundingClientRect().bottom}})()")
        check(f"Splash {nm} ({w}×{h}): Logo unverzerrt, im Bild, keine Überlappung", abs(d["w"] / d["h"] - 1248 / 1521) < 0.01 and d["top"] >= 0 and d["bot"] <= d["vh"] and d["ringBot"] < d["footTop"], str(d))
        if nm in ("iPhone SE 1", "iPhone 14", "iPad", "iPhone quer"): shot(page, "s04_splash_" + nm.replace(" ", "_"))
        page.wait_for_selector("#splash", state="detached", timeout=5000); DELAY.clear()
        m = page.evaluate("(()=>{const r=document.querySelector('.logo .logo-w').getBoundingClientRect();return {w:r.width,h:r.height,l:r.left,r:r.right,t:r.top,b:r.bottom,vw:innerWidth,vh:innerHeight,sw:document.documentElement.scrollWidth}})()")
        check(f"Menü {nm}: Logo unverzerrt, im Bild, kein Seitenscroll", abs(m["w"] / m["h"] - 1248 / 1521) < 0.01 and m["l"] >= 0 and m["r"] <= m["vw"] and m["t"] >= 0 and m["b"] <= m["vh"] and m["sw"] <= m["vw"] + 1, str(m))
        if nm in ("iPhone SE 1", "iPhone 14", "iPad"): shot(page, "s05_menu_" + nm.replace(" ", "_"))
        ctx.close()
    # heller Modus: dunkles Logo sichtbar, weißes versteckt
    ctx = newctx(); page = ctx.new_page(); page.goto(FILE); page.wait_for_selector(".wordmark")
    page.click('[data-act="settings"]'); page.click('[data-act="theme"][data-v="light"]'); page.click('[data-act="menu"]'); page.wait_for_timeout(400)
    check("Heller Modus: dunkle Logo-Variante wird gezeigt", page.locator(".logo .logo-d").is_visible() and not page.locator(".logo .logo-w").is_visible())
    shot(page, "s06_menu_hell"); ctx.close()

    print("Worterklärung (?)")
    def play(page, mode, cats, n_imp=1):
        page.click('[data-act="newGame"]')
        for _ in range(12):
            if page.is_enabled('[data-act="pl-"]'): page.click('[data-act="pl-"]')
        page.click(f'[data-act="mode"][data-m="{mode}"]'); page.click('[data-act="catNone"]')
        for c in cats: page.click(f'[data-act="cat"][data-id="{c}"]')
        page.click('[data-act="start"]'); page.wait_for_selector(".pass-card")
    def S(page): return page.evaluate("JSON.parse(JSON.stringify(window.__IMPOSTER__.state))")
    for mode in ("A", "B"):
        ctx = newctx(); page = ctx.new_page(); errs = []
        page.on("pageerror", lambda e: errs.append(str(e))); page.goto(FILE); page.wait_for_selector(".wordmark")
        play(page, mode, ["hayvanlar", "islam", "markalar"])
        seen_normal = seen_imp = 0; expl = page.evaluate("window.IMPOSTER_ACIKLAMALAR")
        for rnd in range(3):
            r = S(page)["G"]["round"]; word = r["word"]
            for i, pl in enumerate(r["players"]):
                page.wait_for_timeout(470)
                # Übergabe-Bildschirm: weder ? noch Erklärung
                check(f"[{mode}] R{rnd+1} Spieler {i+1}: Übergabe-Bildschirm ohne ?", page.locator(".help-btn").count() == 0)
                page.evaluate("window.__IMPOSTER__.act('explain')")
                check(f"[{mode}] explain-Aktion vor der Rollenanzeige wirkungslos", page.locator("#modal.hidden").count() == 1)
                page.click('[data-act="seeRole"]'); page.wait_for_selector(".role-card")
                body_html = page.inner_html("body")
                if pl["imposter"]:
                    seen_imp += 1
                    check(f"[{mode}] Imposter ({pl['name']}): kein Fragezeichen im DOM", page.locator(".help-btn").count() == 0 and page.locator('[data-act="explain"]').count() == 0 and "?" not in page.inner_text(".role-card"))
                    check(f"[{mode}] Imposter: Erklärung des Wortes nirgends im DOM", expl[word] not in body_html)
                    page.evaluate("window.__IMPOSTER__.act('explain')")
                    check(f"[{mode}] Imposter: explain-Aktion öffnet nichts", page.locator("#modal.hidden").count() == 1 and page.inner_text("#modal") == "")
                    if mode == "B": check("[B] Imposter-Wort (Ersatzwort) ohne ?", page.locator(".help-btn").count() == 0)
                else:
                    seen_normal += 1
                    check(f"[{mode}] Normal ({pl['name']}): ? neben dem Wort sichtbar", page.locator(".secret-wrap .help-btn").is_visible())
                    check(f"[{mode}] Erklärung steht vor dem Antippen nicht im DOM", expl[word] not in body_html)
                    page.click(".help-btn"); page.wait_for_selector("#modal:not(.hidden) .box.explain")
                    mt = page.text_content("#modal")
                    check(f"[{mode}] Fenster zeigt Wort + passende Erklärung ({word})", word in mt and expl[word] in mt and "Kelime açıklaması" in mt)
                    if rnd == 0 and i == 0: shot(page, f"s07_erklaerung_{mode}")
                    # Schließen: Anladım
                    page.click('#modal [data-act="closeModal"]'); check("Fenster schließt per „Anladım“", page.locator("#modal.hidden").count() == 1 and page.inner_text("#modal") == "")
                    # Schließen: Tippen außerhalb
                    page.click(".help-btn"); page.wait_for_selector("#modal:not(.hidden)")
                    page.mouse.click(5, 5); page.wait_for_timeout(100)
                    check("Fenster schließt per Tippen daneben", page.locator("#modal.hidden").count() == 1)
                    # Schließen: Escape
                    page.click(".help-btn"); page.keyboard.press("Escape"); page.wait_for_timeout(100)
                    check("Fenster schließt per Esc", page.locator("#modal.hidden").count() == 1)
                    # Rolle verbergen (App im Hintergrund) schließt Fenster ebenfalls
                    page.click(".help-btn")
                    page.evaluate("Object.defineProperty(document,'hidden',{value:true,configurable:true}); document.dispatchEvent(new Event('visibilitychange'))")
                    page.wait_for_timeout(100)
                    check("Hintergrund-Wechsel schließt Fenster und Rolle", page.locator("#modal.hidden").count() == 1 and page.locator(".role-card").count() == 0)
                    page.evaluate("Object.defineProperty(document,'hidden',{value:false,configurable:true})")
                    page.wait_for_timeout(470); page.click('[data-act="seeRole"]'); page.wait_for_selector(".role-card")
                page.wait_for_timeout(470); page.click('[data-act="ready"]')
            page.wait_for_timeout(470); page.click('[data-act="startDisc"]'); page.wait_for_timeout(470); page.click('[data-act="discEnd"]'); page.wait_for_timeout(470); page.click('[data-act="showResults"]'); page.wait_for_selector(".plist")
            check(f"[{mode}] Ergebnisbildschirm ohne ? / Erklärungsfenster", page.locator(".help-btn").count() == 0)
            page.wait_for_timeout(470)
            if rnd < 2: page.click('[data-act="replay"]'); page.wait_for_selector(".pass-card")
        check(f"[{mode}] Beide Rollen getestet (normal={seen_normal}, imposter={seen_imp})", seen_normal > 0 and seen_imp > 0)
        check(f"[{mode}] Keine Seitenfehler", errs == [], str(errs))
        ctx.close()

    # Fallback für Wörter ohne Erklärung (leere / fehlende Datei)
    for label, body in (("leere Tabelle", "window.IMPOSTER_ACIKLAMALAR = {};"), ("Teil-Tabelle", "window.IMPOSTER_ACIKLAMALAR = {'Kedi':'Test'};")):
        ctx = newctx(); page = ctx.new_page()
        page.route("**/aciklamalar.js", lambda r, _req, b=body: r.fulfill(status=200, content_type="application/javascript", body=b))
        page.goto(HTTP); page.wait_for_selector(".wordmark"); play(page, "A", ["hayvanlar"])
        for i in range(3):
            r = S(page)["G"]["round"]
            page.wait_for_timeout(470); page.click('[data-act="seeRole"]'); page.wait_for_selector(".role-card")
            pl = r["players"][i]
            if not pl["imposter"]:
                page.click(".help-btn"); page.wait_for_selector("#modal:not(.hidden)")
                txt = page.inner_text("#modal")
                if label == "Teil-Tabelle" and pl["word"] == "Kedi": check("Hinterlegte Erklärung wird genutzt", "Test" in txt)
                else: check(f"Ersatztext bei fehlender Erklärung ({label}: {pl['word']})", "henüz kısa bir açıklama eklenmedi" in txt and pl["word"] in txt and "Hayvanlar" in txt)
                page.click('#modal [data-act="closeModal"]')
            page.wait_for_timeout(470); page.click('[data-act="ready"]')
        ctx.close()

    print("Gespeicherte Daten bleiben erhalten")
    ctx = newctx(); page = ctx.new_page()
    old = {"names": ["Ayşe", "Çağrı", "Ömer", "Şule"], "imposters": 1, "categories": ["islam"], "mixed": False, "mode": "B", "timerOn": True, "timerMin": 5, "hints": True, "sound": False, "anim": True}
    page.add_init_script("if(!localStorage.getItem('imposter_tr_ayarlar_v1')) localStorage.setItem('imposter_tr_ayarlar_v1', %s)" % json.dumps(json.dumps(old)))
    page.goto(FILE); page.wait_for_selector(".wordmark"); page.click('[data-act="newGame"]')
    s = S(page)["S"]
    check("Alte gespeicherte Einstellungen (ohne Theme-Feld) werden übernommen", s["names"] == old["names"] and s["mode"] == "B" and s["categories"] == ["islam"] and s["timerMin"] == 5 and s["hints"] is True and s["theme"] == "dark")
    ctx.close()

    print("Offline und Konsole")
    ctx = newctx(); reqs = []; ctx.on("request", lambda r: reqs.append(r.url)); ctx.route("http*://**", lambda r: r.abort())
    page = ctx.new_page(); errs = []; page.on("pageerror", lambda e: errs.append(str(e))); page.on("console", lambda m: errs.append(m.text) if m.type == "error" else None)
    page.goto(FILE); page.wait_for_selector("#splash", state="detached", timeout=5000)
    check("Offline (file://): keine Netzwerkanfragen, keine Fehler", [u for u in reqs if not u.startswith(("file://", "data:"))] == [] and errs == [], str(errs))
    ctx.close(); b.close()
srv.shutdown()
print(f"\n{passed} SAMIX-Prüfungen bestanden")

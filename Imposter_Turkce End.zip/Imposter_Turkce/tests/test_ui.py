"""Arayüz testi (Playwright, Chromium). Kullanım: python3 tests/test_ui.py <index.html yolu>"""
import sys, re, json, pathlib
from playwright.sync_api import sync_playwright

index = pathlib.Path(sys.argv[1]).resolve()
shots = pathlib.Path(sys.argv[2]) if len(sys.argv) > 2 else None
URL = index.as_uri()
passed = 0
def check(name, cond, extra=""):
    global passed
    if not cond:
        print("  ✗ FAIL:", name, extra); sys.exit(1)
    passed += 1; print("  ✓", name)

def state(page): return page.evaluate("JSON.parse(JSON.stringify(window.__IMPOSTER__.state))")
def click(page, act, **kw):
    sel = f'[data-act="{act}"]' + "".join(f'[data-{k}="{v}"]' for k, v in kw.items())
    page.click(sel, timeout=3000)
def text(page): return page.inner_text("body")
def no_hscroll(page): return page.evaluate("document.documentElement.scrollWidth <= window.innerWidth + 1 && document.getElementById('app').scrollWidth <= window.innerWidth + 1")

with sync_playwright() as p:
    b = p.chromium.launch()
    ctx = b.new_context(viewport={"width": 390, "height": 844}, device_scale_factor=2, has_touch=True, is_mobile=True, locale="tr-TR")
    requests = []
    ctx.on("request", lambda r: requests.append(r.url))
    ctx.route("http*://**", lambda r: r.abort())   # internet kapalı gibi
    page = ctx.new_page()
    errors = []
    page.on("pageerror", lambda e: errors.append(str(e)))
    page.on("console", lambda m: errors.append(m.text) if m.type == "error" else None)
    page.goto(URL)
    page.wait_for_selector(".wordmark")

    def shot(name):
        if shots: page.wait_for_timeout(450); page.screenshot(path=str(shots / f"{name}.png"))

    print("Ana menü")
    t = text(page)
    check("Menü Türkçe düğmeler", all(s in t for s in ["Yeni Oyun", "Nasıl Oynanır?", "Ayarlar"]))
    check("Menüde İngilizce arayüz yok", not re.search(r"\b(Settings|New Game|Play|Start|Menu|Back)\b", t))
    shot("01_menu")

    click(page, "how"); check("Nasıl Oynanır açılır", "Sözlü oylama" in text(page)); shot("02_nasil"); check("nasıl: yatay taşma yok", no_hscroll(page))
    click(page, "menu"); click(page, "settings"); check("Ayarlar açılır", "Ses efektleri" in text(page) and "Animasyonlar" in text(page)); shot("03_ayarlar")
    click(page, "menu")

    print("Kurulum")
    click(page, "newGame"); shot("04_kurulum")
    check("Kurulum: yatay taşma yok", no_hscroll(page))
    s = state(page)["S"]
    check("Varsayılan 5 oyuncu, sayaç kapalı, mod A", len(s["names"]) == 5 and s["timerOn"] is False and s["mode"] == "A")
    check("Varsayılan isimler", s["names"][0] == "Oyuncu 1")
    # oyuncu sınırları
    for _ in range(10): 
        if page.is_enabled('[data-act="pl+"]'): click(page, "pl+")
    check("En fazla 12 oyuncu", len(state(page)["S"]["names"]) == 12 and not page.is_enabled('[data-act="pl+"]'))
    for _ in range(10): click(page, "im+") if page.is_enabled('[data-act="im+"]') else None
    check("12 oyuncuda en çok 10 imposter", state(page)["S"]["imposters"] == 10)
    for _ in range(12):
        if page.is_enabled('[data-act="pl-"]'): click(page, "pl-")
    s = state(page)["S"]
    check("3 oyuncu ve imposter 1'e iner", len(s["names"]) == 3 and s["imposters"] == 1 and not page.is_enabled('[data-act="im+"]'))
    click(page, "pl+"); click(page, "pl+"); click(page, "pl+")   # 6
    click(page, "im+")                                          # 2 imposter
    # isim düzenleme
    inp = page.locator('input[data-name="0"]'); inp.fill("Ayşe"); page.locator('input[data-name="1"]').fill("Çağrı"); page.locator('input[data-name="2"]').fill("Ömer"); page.locator('input[data-name="2"]').blur()
    check("İsimler düzenlenir (Türkçe karakter)", state(page)["S"]["names"][:3] == ["Ayşe", "Çağrı", "Ömer"])
    # yinelenen isim hatası
    page.locator('input[data-name="3"]').fill("ayşe"); page.locator('input[data-name="3"]').blur()
    click(page, "start"); page.wait_for_timeout(300)
    check("Aynı isim uyarısı Türkçe", "Aynı isim" in page.inner_text("#toast") and state(page)["G"]["screen"] == "setup")
    page.locator('input[data-name="3"]').fill("Deniz"); page.locator('input[data-name="3"]').blur()
    # kategori işlemleri
    click(page, "catNone"); check("Seçimi temizle", state(page)["S"]["categories"] == [] and "Henüz kategori seçilmedi" in text(page))
    click(page, "start"); page.wait_for_timeout(300)
    check("Kategorisiz başlatma engellenir", state(page)["G"]["screen"] == "setup" and "kategori" in page.inner_text("#toast"))
    click(page, "catAll"); check("Tümünü seç", len(state(page)["S"]["categories"]) == 26)
    click(page, "catNone"); click(page, "cat", id="islam"); click(page, "cat", id="hayvanlar")
    check("Çoklu seçim + özet", state(page)["S"]["categories"] == ["islam", "hayvanlar"] and "2</b> kategori seçili" in page.inner_html(".cat-sum"))
    click(page, "mixed"); check("Karışık Kategoriler açılır", state(page)["S"]["mixed"] and "Karışık Kategoriler" in page.inner_text(".cat-sum"))
    click(page, "mixed"); click(page, "catNone"); click(page, "cat", id="islam")
    click(page, "mode", m="B"); check("Mod B seçilir", state(page)["S"]["mode"] == "B")
    # ipucu + animasyon anahtarı
    page.locator('input[data-chg="hints"]').check(force=True); check("İpucu anahtarı çalışır", state(page)["S"]["hints"] is True)
    page.locator('input[data-chg="anim"]').uncheck(force=True)
    check("Animasyon kapatma gövdeye yansır", page.evaluate("document.body.classList.contains('no-anim')"))
    page.locator('input[data-chg="anim"]').check(force=True)
    page.locator('input[data-chg="sound"]').uncheck(force=True); check("Ses kapatılır", state(page)["S"]["sound"] is False)
    page.locator('input[data-chg="timerOn"]').check(force=True); check("Sayaç süre ayarı görünür", page.is_visible('[data-act="tm+"]'))
    click(page, "tm+"); check("Sayaç süresi artar", state(page)["S"]["timerMin"] == 4)
    shot("05_kurulum_alt")
    page.locator('input[data-chg="timerOn"]').uncheck(force=True)

    print("Rol dağıtımı")
    names = state(page)["S"]["names"]
    click(page, "start"); page.wait_for_selector(".pass-card")
    r = page.evaluate("window.__IMPOSTER__.state.G.round")
    check("Tur: 6 oyuncu, 2 imposter, mod B, kelime İslam", len(r["players"]) == 6 and sum(p["imposter"] for p in r["players"]) == 2 and r["mode"] == "B" and r["category"] == "İslam")
    word, alt = r["word"], r["alt"]
    shot("06_sira")
    for i, pl in enumerate(r["players"]):
        t = text(page)
        check(f"[{i+1}] geçiş ekranı yalnız ismi gösterir, kelime/rol yok", pl["name"] in t and word not in t and alt not in t and "IMPOSTER" not in t and "Normal Oyuncu" not in t)
        page.wait_for_timeout(480); click(page, "seeRole"); page.wait_for_selector(".role-card")
        t = text(page)
        if pl["imposter"]:
            check(f"[{i+1}] imposter: rol + benzer kelime ({alt})", "IMPOSTER" in t and alt in t and (word not in t.replace(alt, "")) and "Kategori: İslam" in t)
        else:
            check(f"[{i+1}] normal: rol + gizli kelime ({word})", "Normal Oyuncu" in t and word in t and "IMPOSTER" not in t)
        if i == 0: shot("07_rol_normal" if not pl["imposter"] else "07_rol_imposter")
        if i == 1: shot("07b_rol")
        page.wait_for_timeout(500)
        click(page, "ready")
        if i < 5:
            page.wait_for_selector(".pass-card")
            # çift dokunuş koruması: hemen "Kelimeyi Gör" tıklaması yok sayılmalı
            page.evaluate("document.querySelector('[data-act=seeRole]').click()")
            check(f"[{i+1}] çift dokunuş sonraki oyuncunun rolünü açmaz", state(page)["G"]["stage"] == "pass")
            page.wait_for_timeout(500)
    check("Tüm roller görüldükten sonra metin", "Herkes rolünü gördü mü? Telefonu bir kenara bırakın ve oyuna başlayın!" in text(page)); shot("08_herkes")
    check("Bu ekranda kelime yok", word not in text(page) and alt not in text(page))
    # arka plana gitme -> rol gizlenir
    page.wait_for_timeout(500)

    print("Tartışma ve sözlü oylama")
    click(page, "startDisc"); page.wait_for_selector(".instr")
    t = text(page)
    check("Tartışma talimatı birebir", "Sırayla ipucu verin. Kelimeyi doğrudan söylemeyin! Imposter'ı bulmaya çalışın." in t)
    check("Sayaç kapalıyken gösterilmez", page.locator("#tm").count() == 0)
    check("Tartışmada gizli kelime/rol yok", word not in t and alt not in t)
    check("Tartışma ekranında giriş alanı yok", page.locator("input, select, textarea").count() == 0)
    shot("09_tartisma"); check("tartışma: yatay taşma yok", no_hscroll(page))
    page.wait_for_timeout(500); click(page, "discEnd"); page.wait_for_selector(".steps")
    t = text(page)
    check("Oylama ekranı sözlü talimat verir", "yüksek sesle" in t and "grup kendisi sayar" in t and "tekrar sözlü oylama" in t)
    check("Dijital oy girişi yok (input/select/oyuncu düğmesi yok)", page.locator("input, select, textarea").count() == 0 and all(n not in t for n in names))
    check("Oylama ekranında kelime yok", word not in t and alt not in t)
    shot("10_oylama"); check("oylama: yatay taşma yok", no_hscroll(page))
    page.wait_for_timeout(500); click(page, "showResults"); page.wait_for_selector(".plist")
    t = text(page)
    check("Sonuç: gizli kelime ve imposter kelimesi", word in t and alt in t and page.locator(".word-box .wd.alt").inner_text() == alt)
    check("Sonuç: her oyuncu ve rol", all(n in t for n in names) and t.count("IMPOSTER") >= 0 and page.locator(".pl.imp").count() == 2 and page.locator(".pl.nor").count() == 4)
    rr = page.evaluate("window.__IMPOSTER__.state.G.round")
    ui_imps = page.eval_on_selector_all(".pl.imp .pn", "els => els.map(e => e.textContent)")
    check("Sonuçtaki imposterlar gerçek rollerle aynı", sorted(ui_imps) == sorted(p["name"] for p in rr["players"] if p["imposter"]))
    check("Oy sayısı/skor/puan uydurulmaz", not re.search(r"(\d+\s*oy\b|puan|skor|sıralama|istatistik)", t, re.I))
    check("Tekrar Oyna ve Ana Menüye Dön var", "Tekrar Oyna" in t and "Ana Menüye Dön" in t)
    check("Kazananı grup belirler açıklaması", "grup birlikte karar verir" in t)
    page.evaluate("document.querySelector('.scroll').scrollTop=0"); shot("11_sonuc")
    page.evaluate("document.querySelector('.scroll').scrollTop=99999"); shot("12_sonuc_alt"); check("sonuç: yatay taşma yok", no_hscroll(page))

    print("Anında tekrar")
    page.wait_for_timeout(500)
    before = page.evaluate("JSON.stringify(window.__IMPOSTER__.state.S)")
    seen_words = set(); seen_roles = set(); prev = word
    for k in range(6):
        click(page, "replay"); page.wait_for_selector(".pass-card")
        st = state(page)
        check(f"Tekrar #{k+1}: ayarlar aynen korunur", json.dumps(st["S"]) == json.dumps(json.loads(before)))
        nr = st["G"]["round"]
        check(f"Tekrar #{k+1}: yeni kelime (önceki değil), İslam, mod B, 2 imposter", nr["word"] != prev and nr["category"] == "İslam" and nr["mode"] == "B" and sum(p["imposter"] for p in nr["players"]) == 2 and st["G"]["idx"] == 0 and st["G"]["stage"] == "pass")
        prev = nr["word"]; seen_roles.add("".join(str(int(p["imposter"])) for p in nr["players"]))
        # turu hızlıca bitir
        for i in range(6):
            page.wait_for_timeout(470); click(page, "seeRole"); page.wait_for_timeout(470); click(page, "ready")
        page.wait_for_timeout(470); click(page, "startDisc"); page.wait_for_timeout(470); click(page, "discEnd"); page.wait_for_timeout(470); click(page, "showResults"); page.wait_for_selector(".plist"); page.wait_for_timeout(470)
    check("Roller turlar arasında değişiyor", len(seen_roles) >= 2)

    print("Sayaç ve gizlilik")
    click(page, "menu"); click(page, "newGame")
    page.locator('input[data-chg="timerOn"]').check(force=True)
    click(page, "start"); page.wait_for_selector(".pass-card")
    for i in range(6):
        page.wait_for_timeout(470); click(page, "seeRole"); page.wait_for_timeout(470); click(page, "ready")
    page.wait_for_timeout(470); click(page, "startDisc"); page.wait_for_selector("#tm")
    check("Sayaç açıkken geri sayım görünür (04:00)", page.inner_text("#tm") in ("04:00", "03:59"))
    page.evaluate("window.__IMPOSTER__.state.G.endAt = Date.now() + 1200")
    page.wait_for_timeout(2200)
    check("Süre dolunca uyarı gösterilir ama oyun otomatik ilerlemez", "Süre doldu" in text(page) and state(page)["G"]["screen"] == "discussion")
    shot("13_sayac_bitti")
    # arka plan -> rol gizleme
    click(page, "exitAsk"); check("Çıkış onayı modalı", "Oyundan çıkılsın mı?" in page.inner_text("#modal")); click(page, "closeModal")
    click(page, "exitAsk"); click(page, "menu"); page.wait_for_selector(".wordmark")
    check("Ana menüye dönünce tur temizlenir", state(page)["G"]["round"] is None)
    click(page, "newGame"); click(page, "start"); page.wait_for_selector(".pass-card"); page.wait_for_timeout(470)
    click(page, "seeRole"); page.wait_for_selector(".role-card")
    page.evaluate("Object.defineProperty(document,'hidden',{value:true,configurable:true}); document.dispatchEvent(new Event('visibilitychange'))")
    page.wait_for_timeout(100)
    check("Uygulama arka plana giderse rol hemen gizlenir", page.locator(".role-card").count() == 0 and state(page)["G"]["stage"] == "pass")

    print("Kalıcılık ve çevrimdışı")
    page.evaluate("Object.defineProperty(document,'hidden',{value:false,configurable:true})")
    page.reload(); page.wait_for_selector(".wordmark"); click(page, "newGame")
    s = state(page)["S"]
    check("Ayarlar yeniden yüklemede korunur", s["names"][:3] == ["Ayşe", "Çağrı", "Ömer"] and s["mode"] == "B" and s["categories"] == ["islam"] and s["sound"] is False)
    ext = [u for u in requests if not u.startswith("file://") and not u.startswith("data:")]
    check("Hiç ağ isteği yok (çevrimdışı)", ext == [], str(ext))
    check("Konsol/sayfa hatası yok", errors == [], str(errors))


    print("Imposter-Wechsel und Erscheinungsbild")
    page.set_viewport_size({"width": 390, "height": 844})
    page.reload(); page.wait_for_selector(".wordmark")
    click(page, "settings"); click(page, "theme", v="light")
    check("Theme: Hell wird gesetzt", page.evaluate("document.documentElement.getAttribute('data-theme')") == "light" and state(page)["S"]["theme"] == "light")
    shot("15_hell_ayarlar")
    click(page, "theme", v="auto"); check("Theme: Otomatik", page.evaluate("document.documentElement.getAttribute('data-theme')") == "auto")
    click(page, "theme", v="dark"); click(page, "menu")
    page.reload(); page.wait_for_selector(".wordmark")
    check("Theme bleibt nach Neuladen erhalten", page.evaluate("document.documentElement.getAttribute('data-theme')") == "dark")
    click(page, "newGame")
    # 3 Spieler, 1 Imposter: viele Runden, niemand mehr als 2x in Folge, alle kommen vor
    for _ in range(12):
        if page.is_enabled('[data-act="pl-"]'): click(page, "pl-")
    page.locator('input[data-name="0"]').fill("A"); page.locator('input[data-name="1"]').fill("B"); page.locator('input[data-name="2"]').fill("C"); page.locator('input[data-name="2"]').blur()
    click(page, "catNone"); click(page, "cat", id="hayvanlar")
    click(page, "start"); page.wait_for_selector(".pass-card")
    seq = [state(page)["G"]["round"]["imposterIdx"][0]]
    for k in range(40):
        page.wait_for_timeout(470)
        page.evaluate("window.__IMPOSTER__.act('replay')")
        page.wait_for_selector(".pass-card")
        r = state(page)["G"]["round"]
        check(f"Runde {k+2}: genau 1 Imposter, UI-Rolle = gewählter Index", len(r["imposterIdx"]) == 1 and r["players"][r["imposterIdx"][0]]["imposter"] and sum(p["imposter"] for p in r["players"]) == 1) if k < 2 else None
        seq.append(r["imposterIdx"][0])
    run = 1; maxrun = 1
    for i in range(1, len(seq)):
        run = run + 1 if seq[i] == seq[i-1] else 1; maxrun = max(maxrun, run)
    check(f"Nie derselbe Spieler mehr als 2x hintereinander (max Serie {maxrun})", maxrun <= 2)
    check("Alle 3 Spieler wurden irgendwann Imposter", set(seq) == {0, 1, 2}, str(seq))

    # küçük ekran
    page.set_viewport_size({"width": 360, "height": 640})
    page.reload(); page.wait_for_selector(".wordmark"); check("360x640 menü taşmıyor", no_hscroll(page)); shot("14_kucuk_menu")
    click(page, "newGame"); check("360x640 kurulum taşmıyor", no_hscroll(page))
    ok_btn = page.evaluate("(()=>{const r=document.querySelector('[data-act=start]').getBoundingClientRect();return r.bottom<=window.innerHeight && r.height>=56})()")
    check("Küçük ekranda Oyunu Başlat düğmesi görünür ve büyük", ok_btn)
    b.close()
print(f"\n{passed} arayüz denetimi geçti")
